# Sympl Pricing Analysis — Design System Starter

This package provides the complete design system and AI coding instructions to build a new Sympl-family platform that matches the look and feel of **SymplPM**.

## What's Included

### Instructions for AI
- **`CLAUDE.md`** — Project-level instructions that Claude Code reads automatically. Defines the architecture, conventions, and design rules.
- **`AGENTS.md`** — Next.js 16 warning (breaking changes from training data).
- **`docs/design-system.md`** — Complete visual reference: colors, typography, layout, component specs, page patterns, and dependencies.

### Reference Components (from SymplPM)
- **`src/components/ui/`** — All 8 shared UI primitives: Button, Input, Card, Dialog, Select, Badge, Tabs, Textarea
- **`src/components/layout/`** — AppShell and Sidebar (reference implementation — adapt nav items for this platform)
- **`src/lib/utils.ts`** — `cn()` utility and common formatters
- **`src/lib/prisma.ts`** — Prisma client singleton with pg adapter
- **`src/app/globals.css`** — Tailwind v4 CSS config
- **`src/app/layout.tsx`** — Root layout with Geist font
- **`src/app/login-page-reference.tsx`** — Login page pattern (reference only — adapt branding)

## How to Use

1. Create a new repo and upload this zip
2. Start a Claude Code session against the repo
3. Ask Claude to scaffold the Pricing Analysis platform — it will read `CLAUDE.md` and `docs/design-system.md` automatically and match the SymplPM look and feel

## Branding

Update these for the new platform:
- Logo text: "Sympl **PA**" (blue-400 accent on "PA")
- Page title in `layout.tsx`: "Sympl PA"
- Login subtitle: "Pricing Analysis Platform"
